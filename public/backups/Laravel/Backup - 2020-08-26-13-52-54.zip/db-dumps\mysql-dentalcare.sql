
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `advice_prescriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advice_prescriptions` (
  `Prescription_id` bigint(20) unsigned NOT NULL,
  `Advice_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `advice_prescriptions_prescription_id_index` (`Prescription_id`),
  KEY `advice_prescriptions_advice_id_index` (`Advice_id`),
  CONSTRAINT `advice_prescriptions_prescription_id_foreign` FOREIGN KEY (`Prescription_id`) REFERENCES `prescriptions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `advice_prescriptions` WRITE;
/*!40000 ALTER TABLE `advice_prescriptions` DISABLE KEYS */;
INSERT INTO `advice_prescriptions` VALUES (15,8,'2020-08-26 02:28:34','2020-08-26 02:28:34'),(15,9,'2020-08-26 02:28:34','2020-08-26 02:28:34'),(15,11,'2020-08-26 02:28:34','2020-08-26 02:28:34'),(15,12,'2020-08-26 02:28:34','2020-08-26 02:28:34');
/*!40000 ALTER TABLE `advice_prescriptions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `advices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `advice` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `advices` WRITE;
/*!40000 ALTER TABLE `advices` DISABLE KEYS */;
INSERT INTO `advices` VALUES (8,'Extruction','2020-04-07 07:21:52','2020-04-07 07:21:52'),(9,'PF','2020-04-07 07:22:02','2020-04-07 07:22:02'),(10,'TF','2020-04-07 07:23:59','2020-04-07 07:23:59'),(11,'Scalling','2020-04-07 07:24:16','2020-04-07 07:24:16'),(12,'RCT Followed by Crown','2020-04-07 07:25:16','2020-04-07 07:25:16');
/*!40000 ALTER TABLE `advices` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `complaint_prescriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `complaint_prescriptions` (
  `Prescription_id` bigint(20) unsigned NOT NULL,
  `Complaint_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `complaint_prescriptions_prescription_id_index` (`Prescription_id`),
  KEY `complaint_prescriptions_complaint_id_index` (`Complaint_id`),
  CONSTRAINT `complaint_prescriptions_prescription_id_foreign` FOREIGN KEY (`Prescription_id`) REFERENCES `prescriptions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `complaint_prescriptions` WRITE;
/*!40000 ALTER TABLE `complaint_prescriptions` DISABLE KEYS */;
INSERT INTO `complaint_prescriptions` VALUES (15,7,'2020-08-26 02:28:34','2020-08-26 02:28:34'),(15,8,'2020-08-26 02:28:34','2020-08-26 02:28:34');
/*!40000 ALTER TABLE `complaint_prescriptions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `complaints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `complaints` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `complaint` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `complaints` WRITE;
/*!40000 ALTER TABLE `complaints` DISABLE KEYS */;
INSERT INTO `complaints` VALUES (7,'Toothache','2020-04-07 07:03:22','2020-04-07 07:03:22'),(8,'Gum Bleeding','2020-04-07 07:07:28','2020-04-07 07:07:28');
/*!40000 ALTER TABLE `complaints` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `doctors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctors` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `dNameEn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dNameBn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vTimeEn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vTimeBn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `designationEn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `designationBn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `addressEn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `addressBn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phoneEn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phoneBn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `doctors` WRITE;
/*!40000 ALTER TABLE `doctors` DISABLE KEYS */;
INSERT INTO `doctors` VALUES (1,'Dr. Prithu Talukder','ডাঃ পৃথু  তালুকদার','From 10am to 7pm , Monday Only.','সোমবার সকাল ১০ টা - সন্ধ্যা ৫ টা।','Oral and Dental Surgeon\r\nB.D.S.(Dhaka Dental College)\r\nPGT (OMS)\r\nConservative Dentistry\r\nTrained in Aesthetic Dentistry\r\nB.M.D.C. Reg no. 9295','ওরাল এন্ড ডেন্টাল সার্জন\r\nবি,ডি,এস(ঢাকা ডেন্টাল কলেজ)\r\nপি,জি,টি (ও,এম,এস)\r\nকনজার্ভেটিভ ডেন্টিস্ট্রি\r\nট্রেইন্ড ইন এসথেটিক ডেন্টিস্ট্রি\r\nবি,এম,ডি,সি রেজিঃ নং-৯২৯৫','Purba Gali, Banglabazar,Begumganj,Noakhali.','বাংলাবাজার, পূর্ব গলি, বেগমগঞ্জ , নোয়াখালী।','01818537093','০১৮১৮-৫৩৭০৯৩',NULL,'2020-04-08 10:03:42'),(2,'Dentist MD Fakhrul Islam','ডেন্টিস্ট মোঃ ফখরুল ইসলাম','Everyday from 10am to 7pm (Remains closed on saturday)','প্রতিদিন সকাল ১০ টা থেকে দুপুর ১টা এবং বিকেল ৪টা থেকে সন্ধ্যা ৭টা। (শনিবার ব্যাতীত)','D.D.T','ডি.ডি.টি (দন্ত্য)','Purba Gali, Banglabazar,Begumganj,Noakhali.','বাংলাবাজার, পূর্ব গলি, বেগমগঞ্জ , নোয়াখালী।','01818537093','০১৮১৮-৫৩৭০৯৩',NULL,'2020-08-26 03:23:01');
/*!40000 ALTER TABLE `doctors` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `examination_prescriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `examination_prescriptions` (
  `Prescription_id` bigint(20) unsigned NOT NULL,
  `Examination_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `examination_prescriptions_prescription_id_index` (`Prescription_id`),
  KEY `examination_prescriptions_examination_id_index` (`Examination_id`),
  CONSTRAINT `examination_prescriptions_prescription_id_foreign` FOREIGN KEY (`Prescription_id`) REFERENCES `prescriptions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `examination_prescriptions` WRITE;
/*!40000 ALTER TABLE `examination_prescriptions` DISABLE KEYS */;
INSERT INTO `examination_prescriptions` VALUES (15,12,'2020-08-26 02:28:34','2020-08-26 02:28:34'),(15,13,'2020-08-26 02:28:34','2020-08-26 02:28:34'),(15,14,'2020-08-26 02:28:34','2020-08-26 02:28:34');
/*!40000 ALTER TABLE `examination_prescriptions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `examinations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `examinations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `onExamination` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `examinations` WRITE;
/*!40000 ALTER TABLE `examinations` DISABLE KEYS */;
INSERT INTO `examinations` VALUES (10,'G carriese teeth','2020-04-07 07:04:31','2020-04-07 07:04:31'),(12,'Calculas on +++','2020-04-07 07:05:24','2020-04-07 07:05:24'),(13,'Broken Teeth','2020-04-07 07:06:14','2020-08-14 03:36:25'),(14,'Impacted Teeth','2020-04-07 07:06:30','2020-04-07 07:06:30'),(16,'Missing Teeth','2020-04-08 07:40:23','2020-04-08 07:40:23'),(17,'Carriese Teeth','2020-05-12 22:17:55','2020-05-12 22:17:55');
/*!40000 ALTER TABLE `examinations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `investigation_prescriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `investigation_prescriptions` (
  `Prescription_id` bigint(20) unsigned NOT NULL,
  `Investigation_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `investigation_prescriptions_prescription_id_index` (`Prescription_id`),
  KEY `investigation_prescriptions_investigation_id_index` (`Investigation_id`),
  CONSTRAINT `investigation_prescriptions_prescription_id_foreign` FOREIGN KEY (`Prescription_id`) REFERENCES `prescriptions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `investigation_prescriptions` WRITE;
/*!40000 ALTER TABLE `investigation_prescriptions` DISABLE KEYS */;
INSERT INTO `investigation_prescriptions` VALUES (15,7,'2020-08-26 02:28:34','2020-08-26 02:28:34'),(15,8,'2020-08-26 02:28:34','2020-08-26 02:28:34'),(15,11,'2020-08-26 02:28:34','2020-08-26 02:28:34');
/*!40000 ALTER TABLE `investigation_prescriptions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `investigations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `investigations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `investigation` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `investigations` WRITE;
/*!40000 ALTER TABLE `investigations` DISABLE KEYS */;
INSERT INTO `investigations` VALUES (7,'Periapical X-Ray','2020-04-07 07:19:31','2020-04-07 07:19:31'),(8,'OPG X-Ray','2020-04-07 07:19:45','2020-04-07 07:20:41'),(9,'RBS','2020-04-07 07:19:53','2020-05-12 23:22:52'),(10,'FBS','2020-04-07 07:20:01','2020-04-07 07:20:01'),(11,'BT/CT','2020-04-07 07:21:06','2020-04-07 07:21:06');
/*!40000 ALTER TABLE `investigations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `medicines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medicines` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `medName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `medicines` WRITE;
/*!40000 ALTER TABLE `medicines` DISABLE KEYS */;
INSERT INTO `medicines` VALUES (28,'Napa Extend','2020-04-07 07:08:14','2020-04-07 07:08:14'),(29,'Avloclav','2020-04-07 07:08:41','2020-08-18 02:52:29'),(30,'Zithrox','2020-04-07 07:09:06','2020-04-07 07:09:06'),(31,'Cleocin','2020-04-07 07:09:22','2020-04-07 07:09:22'),(32,'Kefuclav','2020-04-07 07:09:35','2020-04-07 07:09:35'),(33,'Vasco','2020-04-07 07:09:54','2020-04-07 07:09:54'),(34,'Paricel','2020-04-07 07:10:12','2020-04-07 07:10:12'),(35,'Losectil','2020-04-07 07:10:24','2020-04-07 07:10:24'),(36,'Xeldrin','2020-04-07 07:10:35','2020-04-07 07:10:35'),(38,'Etorix','2020-04-07 07:11:31','2020-04-07 07:11:31'),(39,'Minolac','2020-04-07 07:11:46','2020-04-07 07:11:46'),(40,'Naprosyn','2020-04-07 07:12:11','2020-04-07 07:12:11'),(42,'Bongel Oral gel','2020-04-07 07:13:35','2020-04-07 07:13:35'),(43,'Micoral Oral Gel','2020-04-07 07:14:03','2020-04-07 07:14:03'),(44,'Flamyd','2020-04-07 07:14:38','2020-04-07 07:14:38'),(45,'Oralon','2020-04-08 08:04:38','2020-04-08 08:04:38'),(46,'Hydrogen Per Oxyd','2020-04-08 08:05:50','2020-04-08 08:05:50'),(47,'Napa','2020-05-12 23:08:02','2020-05-12 23:08:02'),(48,'Calgum JR','2020-05-13 14:28:49','2020-05-13 14:28:49');
/*!40000 ALTER TABLE `medicines` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2019_08_19_000000_create_failed_jobs_table',1),(3,'2020_03_28_073717_create_medicines_table',1),(4,'2020_03_28_111931_create_types_table',2),(5,'2020_03_28_113856_create_examinations_table',3),(6,'2020_03_28_114135_create_complaints_table',4),(7,'2020_03_28_114544_create_investigations_table',5),(8,'2020_03_28_114620_create_advices_table',5),(9,'2020_03_28_140019_create_doctors_info_table',6),(10,'2020_03_28_140852_create_doctors_table',7),(11,'2020_03_29_072754_create_newprescriptions_table',8),(15,'2020_04_04_082735_create_takes_table',10),(17,'2020_03_29_074506_create_prescriptions_table',11),(18,'2020_05_12_132417_create_complaint_prescriptions_table',12),(19,'2020_05_12_132730_create__examination_prescriptions_table',12),(20,'2020_05_12_132816_create_investigation_prescriptions_table',12),(21,'2020_05_12_132853_create_advice_prescriptions_table',12);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `prescriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prescriptions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pAge` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `eproblem` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `elu` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `eru` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `eld` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `erd` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `iproblem` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ilu` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `iru` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ild` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ird` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aproblem1` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alu1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aru1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ald1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ard1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aproblem2` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alu2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aru2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ald2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ard2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aproblem3` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alu3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aru3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ald3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ard3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prescription` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meet` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `prescriptions` WRITE;
/*!40000 ALTER TABLE `prescriptions` DISABLE KEYS */;
INSERT INTO `prescriptions` VALUES (15,'Moinul Hasan Chowdhury','25','26 - 8 - 2020','Missing Teeth','a','b','c','d','OPG X-Ray','A','B','C','D','PF','1','2','3','4','Scalling','5','6','7','8','Extruction','9','10','11','12','Mouthwash Xeldrin\r\n     +\r\nCalgum JR\r\n১০ মিঃলিঃ ঔষধের সাথে ১০ মিঃলিঃ পানি মিশিয়ে\r\nকুলকুচি করবেন দিন ২ বার।\r\n\r\nToothpaste mediplus\r\nসকালে এবং রাতে খাবার পর দাঁত ব্রাশ করবেন।\r\n\r\nLotion Losectil\r\n৫/৬ ফোঁটা তুলায় করে দাঁতে/মাড়িতে ঘষবে দিন ৩ বার।','7 days','2020-05-12 12:19:46','2020-08-26 02:28:02');
/*!40000 ALTER TABLE `prescriptions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `takes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `takes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `take` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `takes` WRITE;
/*!40000 ALTER TABLE `takes` DISABLE KEYS */;
INSERT INTO `takes` VALUES (6,'1 + 1 + 1','2020-04-07 07:25:48','2020-04-07 07:25:48'),(7,'1+ 0 +1','2020-04-07 07:26:03','2020-04-07 08:12:11'),(9,'২ চামুচ করে ৩ বার','2020-04-07 07:32:23','2020-04-07 07:32:23'),(10,'১ চামুচ করে ৩ বার','2020-04-07 07:32:40','2020-04-07 07:32:40'),(11,'১ চামুচ করে ২ বার','2020-04-07 07:32:58','2020-04-07 07:32:58'),(12,'১½ চামুচ করে ৩ বার','2020-04-07 08:08:03','2020-04-07 08:08:03'),(13,'১+ ১ +১','2020-04-07 08:10:11','2020-04-07 08:13:09'),(14,'১ + ০ + ১','2020-04-07 08:12:47','2020-04-07 08:12:47'),(15,'প্রতিদিন ১ টা','2020-04-07 08:13:48','2020-04-07 08:13:48'),(18,'1+0+0','2020-05-12 23:33:10','2020-05-12 23:33:10');
/*!40000 ALTER TABLE `takes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `medType` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `types` WRITE;
/*!40000 ALTER TABLE `types` DISABLE KEYS */;
INSERT INTO `types` VALUES (3,'Mouthwash','2020-03-28 05:36:14','2020-03-28 05:36:14'),(7,'Tab.','2020-04-07 07:16:00','2020-04-07 07:16:00'),(8,'Cap.','2020-04-07 07:16:11','2020-04-07 07:16:11'),(9,'Inj.','2020-04-07 07:16:50','2020-04-07 07:16:50'),(10,'Susp.','2020-04-07 07:17:07','2020-04-07 07:17:07'),(11,'Syp.','2020-04-07 07:17:20','2020-04-07 07:17:20'),(12,'Suppository','2020-04-07 07:17:52','2020-04-07 07:17:52'),(14,'Toothpaste','2020-05-12 23:17:38','2020-05-12 23:17:38'),(15,'Lotion','2020-08-14 05:29:04','2020-08-14 05:29:04');
/*!40000 ALTER TABLE `types` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

